// src/app/warranties/page.tsx
import Link from "next/link";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const PAGE_SIZE = 20;

type SearchParams = {
    q?: string;                 // free text: name, provider, policyNo
    assetId?: string;
    expiringFrom?: string;      // YYYY-MM-DD
    expiringTo?: string;        // YYYY-MM-DD
    sort?: "expiresAt" | "name" | "createdAt";
    dir?: "asc" | "desc";
    page?: string;
};

function toInt(s?: string, fallback = 1) {
    const n = Number.parseInt(s ?? "", 10);
    return Number.isFinite(n) && n > 0 ? n : fallback;
}
function fmtDate(d?: Date | string | null) {
    if (!d) return "—";
    const dt = d instanceof Date ? d : new Date(d);
    try {
        return new Intl.DateTimeFormat(undefined, { year: "numeric", month: "short", day: "2-digit" }).format(dt);
    } catch {
        const y = dt.getFullYear();
        const m = String(dt.getMonth() + 1).padStart(2, "0");
        const day = String(dt.getDate()).padStart(2, "0");
        return `${y}/${m}/${day}`;
    }
}

export default async function WarrantiesIndex({ searchParams }: { searchParams: SearchParams }) {
    const q = (searchParams.q ?? "").trim();
    const assetId = (searchParams.assetId ?? "").trim();
    const expiringFrom = (searchParams.expiringFrom ?? "").trim();
    const expiringTo = (searchParams.expiringTo ?? "").trim();
    const sort = (searchParams.sort as SearchParams["sort"]) ?? "expiresAt";
    const dir = (searchParams.dir as SearchParams["dir"]) ?? "asc";
    const page = toInt(searchParams.page, 1);

    // Data for filters
    const assets = await prisma.asset.findMany({
        select: { id: true, name: true },
        orderBy: { name: "asc" },
    });

    // WHERE
    const where = {
        AND: [
            q
                ? {
                    OR: [
                        { name: { contains: q, mode: "insensitive" } },
                        { provider: { contains: q, mode: "insensitive" } },
                        { policyNo: { contains: q, mode: "insensitive" } },
                        { asset: { name: { contains: q, mode: "insensitive" } } },
                    ],
                }
                : {},
            assetId ? { assetId } : {},
            expiringFrom ? { expiresAt: { gte: new Date(expiringFrom + "T00:00:00") } } : {},
            expiringTo ? { expiresAt: { lte: new Date(expiringTo + "T23:59:59") } } : {},
        ],
    } as const;

    // ORDER
    const orderBy = [{ [sort]: dir }] as any;

    // QUERY
    const [total, warranties] = await Promise.all([
        prisma.warranty.count({ where }),
        prisma.warranty.findMany({
            where,
            orderBy,
            include: { asset: { select: { id: true, name: true } } },
            skip: (page - 1) * PAGE_SIZE,
            take: PAGE_SIZE,
        }),
    ]);

    const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

    // Persist QS (except page)
    const baseQS = new URLSearchParams();
    if (q) baseQS.set("q", q);
    if (assetId) baseQS.set("assetId", assetId);
    if (expiringFrom) baseQS.set("expiringFrom", expiringFrom);
    if (expiringTo) baseQS.set("expiringTo", expiringTo);
    if (sort) baseQS.set("sort", sort);
    if (dir) baseQS.set("dir", dir);

    const pageHref = (p: number) => {
        const copy = new URLSearchParams(baseQS);
        copy.set("page", String(p));
        return `/warranties?${copy.toString()}`;
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <h1 className="text-2xl font-semibold">Warranties</h1>
                <Link href="/warranties/new" className="rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700">
                    New Warranty
                </Link>
            </div>

            {/* Filters */}
            <form className="grid gap-3 md:grid-cols-7">
                <input
                    type="text"
                    name="q"
                    defaultValue={q}
                    placeholder="Search warranty, provider, policy, asset…"
                    className="md:col-span-2 rounded border px-3 py-2"
                />

                <select name="assetId" defaultValue={assetId} className="rounded border px-3 py-2">
                    <option value="">All assets</option>
                    {assets.map((a) => (
                        <option key={a.id} value={a.id}>{a.name}</option>
                    ))}
                </select>

                <input type="date" name="expiringFrom" defaultValue={expiringFrom} className="rounded border px-3 py-2" />
                <input type="date" name="expiringTo" defaultValue={expiringTo} className="rounded border px-3 py-2" />

                <div className="flex gap-2">
                    <select name="sort" defaultValue={sort} className="rounded border px-3 py-2">
                        <option value="expiresAt">Sort: Expires</option>
                        <option value="name">Sort: Name</option>
                        <option value="createdAt">Sort: Created</option>
                    </select>
                    <select name="dir" defaultValue={dir} className="rounded border px-3 py-2">
                        <option value="asc">Asc</option>
                        <option value="desc">Desc</option>
                    </select>
                </div>

                <div className="md:justify-self-end">
                    <button type="submit" className="w-full rounded border px-4 py-2 hover:bg-gray-50">Apply</button>
                </div>
            </form>

            {/* Table */}
            <div className="rounded-lg border">
                <table className="w-full table-fixed border-collapse text-sm">
                    <thead className="bg-gray-50">
                        <tr className="[&>th]:px-3 [&>th]:py-2 text-left">
                            <th className="w-[28%]">Warranty</th>
                            <th className="w-[22%]">Asset</th>
                            <th className="w-[18%]">Provider</th>
                            <th className="w-[18%]">Policy #</th>
                            <th className="w-[14%]">Expires</th>
                        </tr>
                    </thead>
                    <tbody>
                        {warranties.length === 0 ? (
                            <tr>
                                <td colSpan={5} className="px-3 py-6 text-center text-gray-500">No warranties found.</td>
                            </tr>
                        ) : (
                            warranties.map((w) => (
                                <tr key={w.id} className="border-t align-top [&>td]:px-3 [&>td]:py-2">
                                    <td className="truncate">
                                        <Link href={`/warranties/${w.id}`} className="font-medium text-blue-700 hover:underline">
                                            {w.name}
                                        </Link>
                                    </td>
                                    <td className="truncate">
                                        {w.asset ? (
                                            <Link href={`/assets/${w.asset.id}`} className="text-blue-700 hover:underline">
                                                {w.asset.name}
                                            </Link>
                                        ) : "—"}
                                    </td>
                                    <td className="truncate">{(w as any).provider ?? "—"}</td>
                                    <td className="truncate">{(w as any).policyNo ?? "—"}</td>
                                    <td>{fmtDate((w as any).expiresAt)}</td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>

            {/* Paging */}
            <div className="flex items-center justify-between">
                <p className="text-sm text-gray-600">
                    Showing {(page - 1) * PAGE_SIZE + (warranties.length ? 1 : 0)}–{Math.min(page * PAGE_SIZE, total)} of {total}
                </p>
                <div className="flex gap-2">
                    <Link
                        aria-disabled={page <= 1}
                        href={page <= 1 ? "#" : pageHref(page - 1)}
                        className={`rounded border px-3 py-2 ${page <= 1 ? "pointer-events-none opacity-50" : "hover:bg-gray-50"}`}
                    >
                        Prev
                    </Link>
                    <span className="px-2 py-2 text-sm">Page {page} / {totalPages}</span>
                    <Link
                        aria-disabled={page >= totalPages}
                        href={page >= totalPages ? "#" : pageHref(page + 1)}
                        className={`rounded border px-3 py-2 ${page >= totalPages ? "pointer-events-none opacity-50" : "hover:bg-gray-50"}`}
                    >
                        Next
                    </Link>
                </div>
            </div>
        </div>
    );
}
