// src/app/warranties/new/page.tsx
import Link from "next/link";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import { logCreate } from "@/lib/activity";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function toDate(d?: string) {
    return d ? new Date(d + "T12:00:00") : null;
}

// Server action
async function createWarranty(formData: FormData) {
    "use server";
    const name = String(formData.get("name") ?? "").trim();
    const assetId = String(formData.get("assetId") ?? "").trim(); // REQUIRED
    const provider = String(formData.get("provider") ?? "").trim();
    const policyNo = String(formData.get("policyNo") ?? "").trim();
    const expiresAt = String(formData.get("expiresAt") ?? "").trim();

    if (!name) redirect(`/warranties/new?error=${encodeURIComponent("Name is required")}`);
    if (!assetId) redirect(`/warranties/new?error=${encodeURIComponent("Asset is required")}`);

    const created = await prisma.warranty.create({
        data: {
            name,
            provider: provider || null,
            policyNo: policyNo || null,
            expiresAt: toDate(expiresAt),
            asset: { connect: { id: assetId } }, // required relation
        },
    });

    await logCreate("Warranty", created.id, created.name);
    revalidatePath("/warranties");
    redirect(`/warranties/${created.id}?ok=created`);
}

export default async function NewWarrantyPage({
    searchParams,
}: {
    searchParams?: { error?: string; assetId?: string; name?: string };
}) {
    const err = searchParams?.error;
    const preAsset = (searchParams?.assetId ?? "").trim();
    const preName = (searchParams?.name ?? "").trim();

    const assets = await prisma.asset.findMany({
        select: { id: true, name: true },
        orderBy: { name: "asc" },
    });

    return (
        <div className="space-y-6">
            {/* Top bar */}
            <div className="flex items-center justify-between">
                <nav className="text-sm text-gray-600">
                    <Link href="/warranties" className="text-blue-700 hover:underline">Warranties</Link>
                    <span className="mx-2">/</span>
                    <span className="text-gray-800">New</span>
                </nav>
                <Link href="/warranties" className="rounded border px-3 py-2 hover:bg-gray-50">Back to all</Link>
            </div>

            <h1 className="text-2xl font-semibold">New Warranty</h1>

            {err ? (
                <div className="rounded-md border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-700">{err}</div>
            ) : null}

            {/* CREATE FORM */}
            <form action={createWarranty} className="grid max-w-2xl gap-4">
                <label className="grid gap-1">
                    <span className="text-sm text-gray-700">Warranty name</span>
                    <input name="name" defaultValue={preName} required className="rounded border px-3 py-2" />
                </label>

                <label className="grid gap-1">
                    <span className="text-sm text-gray-700">Asset</span>
                    <select name="assetId" defaultValue={preAsset} required className="rounded border px-3 py-2">
                        <option value="">Select an asset…</option>
                        {assets.map((a) => (
                            <option key={a.id} value={a.id}>{a.name}</option>
                        ))}
                    </select>
                </label>

                <div className="grid md:grid-cols-2 gap-4">
                    <label className="grid gap-1">
                        <span className="text-sm text-gray-700">Provider</span>
                        <input name="provider" className="rounded border px-3 py-2" />
                    </label>

                    <label className="grid gap-1">
                        <span className="text-sm text-gray-700">Policy #</span>
                        <input name="policyNo" className="rounded border px-3 py-2" />
                    </label>
                </div>

                <label className="grid gap-1">
                    <span className="text-sm text-gray-700">Expires</span>
                    <input type="date" name="expiresAt" className="rounded border px-3 py-2" />
                </label>

                <div className="flex flex-wrap gap-2">
                    <button type="submit" className="rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700">Create</button>
                    <Link href="/warranties" className="rounded border px-3 py-2 hover:bg-gray-50">Back to all</Link>
                </div>
            </form>
        </div>
    );
}
