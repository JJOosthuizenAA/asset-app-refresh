// src/app/warranties/[id]/page.tsx
import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function fmtDate(d?: Date | string | null) {
    if (!d) return "—";
    const dt = d instanceof Date ? d : new Date(d);
    try {
        return new Intl.DateTimeFormat(undefined, { year: "numeric", month: "short", day: "2-digit" }).format(dt);
    } catch {
        const y = dt.getFullYear();
        const m = String(dt.getMonth() + 1).padStart(2, "0");
        const day = String(dt.getDate()).padStart(2, "0");
        return `${y}/${m}/${day}`;
    }
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
    return (
        <section className="rounded-2xl border border-border bg-surface overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border/70 bg-background/60">
                <h2 className="text-lg font-semibold">{title}</h2>
            </div>
            {children}
        </section>
    );
}
function Th({ children, className = "" }: { children: React.ReactNode; className?: string }) {
    return <th className={`px-4 py-3 text-sm font-semibold text-text ${className}`}>{children}</th>;
}
function Td({ children, className = "" }: { children: React.ReactNode; className?: string }) {
    return <td className={`px-4 py-3 align-top ${className}`}>{children}</td>;
}

export default async function WarrantyShow({
    params,
    searchParams,
}: {
    params: { id: string };
    searchParams?: { ok?: string };
}) {
    const warranty = await prisma.warranty.findUnique({
        where: { id: params.id },
        include: { asset: { select: { id: true, name: true } } },
    });
    if (!warranty) notFound();

    const ok = searchParams?.ok;

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <nav className="text-sm text-gray-600">
                    <Link href="/warranties" className="text-blue-700 hover:underline">Warranties</Link>
                    <span className="mx-2">/</span>
                    <span className="text-gray-800">{warranty.name}</span>
                </nav>
                <div className="flex gap-2">
                    <Link href={`/warranties/${warranty.id}/edit`} className="rounded border px-3 py-2 hover:bg-gray-50">Edit</Link>
                    <Link href="/warranties" className="rounded border px-3 py-2 hover:bg-gray-50">Back to all</Link>
                </div>
            </div>

            <h1 className="text-2xl font-semibold">{warranty.name}</h1>

            {/* Flash banner */}
            {ok && (
                <div className="rounded-md border border-green-300 bg-green-50 px-4 py-3 text-sm text-green-700">
                    {ok === "created" && "Warranty created successfully."}
                    {ok === "1" && "Warranty updated successfully."}
                    {ok === "deleted" && "Warranty deleted."}
                </div>
            )}

            <Section title="Details">
                <table className="w-full text-sm">
                    <tbody className="[&>tr:not(:last-child)]:border-b [&>tr]:border-border/70">
                        <tr>
                            <Th className="w-44 bg-background/60">Asset</Th>
                            <Td>
                                {warranty.asset ? (
                                    <Link href={`/assets/${warranty.asset.id}`} className="text-blue-700 hover:underline">
                                        {warranty.asset.name}
                                    </Link>
                                ) : "—"}
                            </Td>
                        </tr>
                        <tr>
                            <Th className="bg-background/60">Provider</Th>
                            <Td>{(warranty as any).provider ?? "—"}</Td>
                        </tr>
                        <tr>
                            <Th className="bg-background/60">Policy #</Th>
                            <Td>{(warranty as any).policyNo ?? "—"}</Td>
                        </tr>
                        <tr>
                            <Th className="bg-background/60">Expires</Th>
                            <Td>{fmtDate((warranty as any).expiresAt)}</Td>
                        </tr>
                    </tbody>
                </table>
            </Section>
        </div>
    );
}
